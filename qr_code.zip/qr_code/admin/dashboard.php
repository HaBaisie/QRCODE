<?php
$page = "DASHBOARD";
require_once "header.php";
header('location: add-certificate.php');
 ?>

 <?php require_once "footer.php"; ?>